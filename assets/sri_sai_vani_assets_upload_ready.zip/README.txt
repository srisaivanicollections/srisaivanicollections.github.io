SRI SAI VANI COLLECTIONS
Production asset folder structure

Upload this entire folder under your repository's assets/ directory.

Final GitHub structure:
assets/
  client-chronicles/
  our-collection/
  store-details/
  shared/

Do not rename the folders or files after uploading, because the website can reference these paths directly.
